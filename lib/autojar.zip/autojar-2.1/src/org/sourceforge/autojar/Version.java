package org.sourceforge.autojar;

/** autojar version. */

public class Version
{
    static public final String VERSION = "2.1";
    static public final String BUILD = "2011-05-13 14:29";
    static public final String AUTHOR = "Bernd Eggink (bernd.eggink@sudrala.de)";
}
